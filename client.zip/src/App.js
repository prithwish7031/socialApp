import "./App.css"
// import Home from "./pages/Home";
// import Profile from "./components/Profile/Profile";
import Auth from "../src/pages/Auth/Auth.jsx";

function App() {
  return (
    <div className="App">
      <div className="blur" style={{top:'-12%' , right:'0'}}></div>
      <div className="blur" style={{top:'36%', left: '-3rem'}}></div>
      {/* <Home/> */}
       {/* <Profile/> */}
     <Auth/>
    </div>
  );
}
export default App;
