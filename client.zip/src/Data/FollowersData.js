import img1 from "./../img/img1.png";
import img2 from "./../img/img2.png";
import img3 from "./../img/img3.png";
import img4 from "./../img/img4.jpg";

export const Followers = [
{ name:"Prithwish Chowdhury", username: "Prithwish70", img:img1},
{ name: "Rahina Khatun", username: "Rahina1", img:img4},
{ name:"Chaitali Bhattacharjee", username: "Chaitali2", img:img2},
{ name:"Trisha Karmakar", username: "Trisha1", img:img3},

];