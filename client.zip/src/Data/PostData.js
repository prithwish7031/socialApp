import postPic1 from '../../src/img/postpic1.jpg';
import postPic2 from '../../src/img/postpic2.jpg';
import postPic3 from '../../src/img/postpic3.JPG';

export const PostData = [
    {
        img: postPic1,
        name: 'Prithwish',
        desc: 'Testing Photo',
        likes: 20,
        liked: true
    },

    {
        img: postPic2,
        name: 'Prithwish',
        desc: 'Testing Photo 2',
        likes: 12,
        liked: false
    },
    {
        img: postPic3,
        name: 'Prithwish',
        desc: 'Testing Photo 3',
        likes: 8,
        liked: false
    },
]