export const TrendData = [
    {
        name: "Sanju",
        shares: 97,
    },

    {
        name: "Prithwish",
        shares: 45,
    },

    {
        name: "Sonai",
        shares: 102,
    },

    {
        name: "Darshana",
        shares: 97,
    },

    {
        name: "Chaitali",
        shares: 52,
    },
]