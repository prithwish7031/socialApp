import { UilPen } from '@iconscout/react-unicons';
import React, { useState } from 'react';
import './InfoCard.css';
import { Modal } from '@mantine/core';

const InfoCard = () => {
    const [opened, setOpened] = useState(false);
    const [profilePic, setProfilePic] = useState(null);
    const [coverPic, setCoverPic] = useState(null);

    const ProfileModal = ({ opened, onClose }) => {
        const [status, setStatus] = useState('');

        const handleStatusChange = (e) => {
            setStatus(e.target.value);
        };

        const handleProfilePicChange = (e) => {
            if (e.target.files && e.target.files[0]) {
                const reader = new FileReader();
                reader.onload = (e) => {
                    setProfilePic(e.target.result);
                };
                reader.readAsDataURL(e.target.files[0]);
            }
        };

        const handleCoverPicChange = (e) => {
            if (e.target.files && e.target.files[0]) {
                const reader = new FileReader();
                reader.onload = (e) => {
                    setCoverPic(e.target.result);
                };
                reader.readAsDataURL(e.target.files[0]);
            }
        };

        const handleSubmit = (e) => {
            e.preventDefault();
            console.log("Selected status:", status);
            console.log("Selected profile picture:", profilePic);
            console.log("Selected cover photo:", coverPic);
            // You can add further logic here, such as sending the form data to a backend server
        };

        const handleReset = () => {
            setStatus('');
            setProfilePic(null);
            setCoverPic(null);
        };

        return (
            <Modal
                opened={opened}
                onClose={onClose}
                transitionProps={{ transition: 'fade', duration: 800, timingFunction: 'linear' }}
                title="Your Info"
                titleProps={{ align: 'center', style: { fontSize: '18px', fontWeight: 'bold' } }}
            >
                <div className="form-container">
                    <form onSubmit={handleSubmit} onReset={handleReset}>
                        <div className="clearfix">
                            <p>
                                <label htmlFor="firstname">Firstname:</label>
                                <input type="text" className="infoInput" id="firstname" name="firstname" placeholder="Firstname" />
                            </p>
                            <p>
                                <label htmlFor="lastname">Lastname:</label>
                                <input type="text" className="infoInput" id="lastname" name="lastname" placeholder="Lastname" />
                            </p>
                        </div>

                        <div className="clearfix">
                            <p>
                                <label htmlFor="status">Relationship Status:</label>
                                <select className="infoInput" name="status" id="status" value={status} onChange={handleStatusChange}>
                                    <option value="">Select</option>
                                    <option value="Single">Single</option>
                                    <option value="In a Relationship">In a Relationship</option>
                                    <option value="Married">Married</option>
                                    <option value="Divorced">Divorced</option>
                                </select>
                            </p>
                            <p>
                                <label htmlFor="livesin">Lives In:</label>
                                <input type="text" className="infoInput" id="livesin" name="livesin" placeholder="Live in" />
                            </p>
                        </div>

                        <div className="clearfix">
                            <p> 
                                <label htmlFor="worksat">Works at:</label>
                                <input type="text" className="infoInput" id="worksat" name="worksat" placeholder="Works at" />
                            </p> 
                        </div>
                        <div className="clearfix">
                            <p> 
                                <label htmlFor="profilePic" className="file-label">Profile Photo:</label>
                                <input type="file" className="infoInput" id="profilePic" name="profilePic" hidden onChange={handleProfilePicChange}/>
                                <label htmlFor="profilePic" className="upload-button">Upload Image</label>
                                {profilePic && <img src={profilePic} alt="Profile Photo Preview" className="preview-image" />}
                            </p> 
                            <p> 
                                <label htmlFor="coverPic" className="file-label">Cover Photo:</label>
                                <input type="file" className="infoInput" id="coverPic" name="coverPic" hidden onChange={handleCoverPicChange}/>
                                <label htmlFor="coverPic" className="upload-button">Upload Image</label>
                                {coverPic && <img src={coverPic} alt="Cover Photo Preview" className="preview-cover" />}
                            </p>
                        </div>

                        <input type="reset" className="infoInput" value="Reset" />
                        <button type="submit" className="infoInput">Update</button>
                    </form>
                </div>
            </Modal>
        );
    };

    return (
        <div className="InfoCard">
            <div className="infoHead">
                <h4>Your Info </h4>
                <div>
                    <UilPen width='2rem' height='1.2rem' onClick={() => setOpened(true)} />
                </div>
            </div>

            <div className="info">
                <span>
                    <b>Status-</b>
                </span>
                <span>In a Relationship</span>
            </div>

            <div className="info">
                <span>
                    <b>Lives in- </b>
                </span>
                <span>Berhampore</span>
            </div>

            <div className="info">
                <span>
                    <b>Works at- </b>
                </span>
                <span>Student</span>
            </div>

            <button className="button logout-button">Log Out</button>

            <ProfileModal opened={opened} onClose={() => setOpened(false)} />
        </div>
    );
}

export default InfoCard;
