import React, { useState, useRef } from "react";
import "./PostShare.css";
import ProfileImage from "../../img/profileImg.jpg";
import {
  UilScenery,
  UilPlayCircle,
  UilLocationPoint,
  UilSchedule,
  UilTimes,
} from "@iconscout/react-unicons";

const PostShare = () => {
  const [image, setImage] = useState(null);
  const [video, setVideo] = useState(null);
  const [location, setLocation] = useState(null);
  const [errorMessage, setErrorMessage] = useState(null);
  const imageRef = useRef();
  const videoRef = useRef();

  const onImageChange = (event) => {
    const file = event.target.files[0];
    const allowedTypes = ["image/jpeg", "image/jpg", "image/png", "image/gif"];

    if (file && allowedTypes.includes(file.type)) {
      setImage({
        image: URL.createObjectURL(file),
      });
      setErrorMessage(null);
    } else {
      setImage(null);
      setErrorMessage("Unsupported file format. Only .jpg, .jpeg, .png, and .gif formats are supported.");
    }
  };

  const onVideoChange = (event) => {
    const file = event.target.files[0];
    const allowedTypes = ["video/mp4", "video/mkv"];

    if (file && allowedTypes.includes(file.type)) {
      setVideo({
        video: URL.createObjectURL(file),
      });
      setErrorMessage(null);
    } else {
      setVideo(null);
      setErrorMessage("Unsupported file format. Only .mp4 and .mkv formats are supported.");
    }
  };

  const getLocation = () => {
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition((position) => {
        setLocation({
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
        });
        setErrorMessage(null);
      }, () => {
        setErrorMessage("Unable to retrieve your location.");
      });
    } else {
      setErrorMessage("Geolocation is not supported by your browser.");
    }
  };

  return (
    <div className="PostShare">
      <img src={ProfileImage} alt="ProfileImg" />
      <div>
        <input type="text" placeholder="What's happening in your mind?" />
        <div className="postOptions">
          <div
            className="option"
            style={{ color: "var(--photo)" }}
            onClick={() => imageRef.current.click()}
          >
            <UilScenery />
            Photos
          </div>

          <div
            className="option"
            style={{ color: "var(--video)" }}
            onClick={() => videoRef.current.click()}
          >
            <UilPlayCircle />
            Videos
          </div>
          <div
            className="option"
            style={{ color: "var(--location)" }}
            onClick={getLocation}
          >
            <UilLocationPoint />
            Location
          </div>
          <div className="option" style={{ color: "var(--shedule)" }}>
            <UilSchedule />
            Schedule
          </div>
          <button className="button ps-button">Share</button>

          <div style={{ display: "none" }}>
            <input
              type="file"
              name="myImage"
              ref={imageRef}
              onChange={onImageChange}
              accept=".jpg, .jpeg, .png, .gif"
            />
            <input
              type="file"
              name="myVideo"
              ref={videoRef}
              onChange={onVideoChange}
              accept=".mp4, .mkv"
            />
          </div>
        </div>

        {image && (
          <div className="previewImage">
            <UilTimes onClick={() => setImage(null)} />
            <img src={image.image} alt="" />
          </div>
        )}

        {video && (
          <div className="previewVideo">
            <UilTimes onClick={() => setVideo(null)} />
            <video controls>
              <source src={video.video} type="video/mp4" />
              <source src={video.video} type="video/mkv" />
              Your browser does not support the video tag.
            </video>
          </div>
        )}

        {location && (
          <div className="previewLocation">
            <UilTimes onClick={() => setLocation(null)} />
            <p>Latitude: {location.latitude}</p>
            <p>Longitude: {location.longitude}</p>
          </div>
        )}

        {errorMessage && (
          <div className="error-message">
            {errorMessage}
          </div>
        )}
      </div>
    </div>
  );
};
export default PostShare;
