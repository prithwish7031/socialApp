import React from "react";
import './Profile.css';
import ProfileLeft from  "../ProfileLeft/ProfileLeft.jsx"
import ProfileCard from "./../ProfileCard/ProfileCard.jsx"
import PostSide from "../PostSide/PostSide.jsx"
import RightSide from "../RightSide/RightSide.jsx"
const Profile =() =>{
    return(
        <div className="Profile">
            <ProfileLeft/>
            <div className="Profile-center">
                <ProfileCard/>
                <PostSide/>
            </div>
            <RightSide/>
        </div>
    )
}
export default Profile