import React, { useState }  from "react";
import './RightSide.css';
import Home from '../../img/home.png'
import Noti from '../../img/noti.png'
import Comments from '../../img/comment.png'
import {UilSetting} from '@iconscout/react-unicons'
import TrendCard from './../TrendCard/TrendCard'
import { Modal } from '@mantine/core';
import PostShare from "../PostShare/PostShare"
const RightSide =() =>{
    const [opened, setOpened] = useState(false);
    return(
        <div className="RightSide">
            <div className="navIcons">
                <img src={Home} alt="" />
                <UilSetting/>
                <img src={Noti} alt="" />
                <img src={Comments} alt="" />
            </div>

            <TrendCard/>
            <button className="button r-button" onClick={() => setOpened(true)}>Share</button>
            <SharedModal opened={opened} onClose={() => setOpened(false)} />
        </div>

    )
}

const SharedModal = ({ opened, onClose }) => {
    const [status, setStatus] = useState('');
    return (
        <Modal
            opened={opened}
            onClose={onClose}
            title="Share"
            padding="md"
            size="sl"
        >
           <PostShare/> 
        </Modal>
    );
}

export default RightSide

