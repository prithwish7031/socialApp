import React from "react";
import './TrendCard.css'
import { TrendData } from "../../Data/TrendData.js";

const TrendCard = () => {
    return (
        <div className="TrendCard">
            <h3>Trend for you</h3>
            {TrendData.map((trend) => (
                <div className="trend" key={trend.id}>
                    <span>#{trend.name}</span>
                    <span>{trend.shares}</span>
                </div>
            ))}
        </div>
    );
};

export default TrendCard;
