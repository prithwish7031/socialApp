import React, { useState } from "react";
import "./Auth.css";
import Logo from '../../img/logo1.png';
import {useDispatch} from 'react-redux';
import {logIn} from '../../actions/AuthAction.js';
import {signUp} from '../../actions/AuthAction.js';
const Auth = () => {
   const [isSignUp, setIsSignUp] = useState(true);

   const dispatch = useDispatch()
   const [data, setData] = useState({
        firstName: "",
        lastName: "",
        username: "",
        password: "", 
        cpassword: "" 
    }); 
   // Handling the changes
   const [cpasswordError, setCpasswordError] = useState(false);
   const handleChange = (e) => {
        setData({ ...data, [e.target.name]: e.target.value });
   };
   // Submission handling of the form
   const handleSubmit = (e) => {
        e.preventDefault();
        if (isSignUp) {
            data.password ===data.cpassword
             ? dispatch(signUp(data))
            : setCpasswordError(false);
        }
        else{
            dispatch(logIn(data))
        }
   };

   const resetForm = () => {
        setCpasswordError(false);
        setData({
            firstName: "",
            lastName: "",
            username: "",
            password: "", 
            cpassword: "" 
        });
   };

   return (
        <div className="Auth">
            {/* left side */}
            <div className="a-left">
                <img src={Logo} alt="" />
                <div className="Webname">
                    <h2>Virtual World</h2>
                    <h4>Berhampore Girls College</h4>
                </div>
            </div>
            {/* right side */}
            <div className="a-right">
                <form className="infoForm authForm" onSubmit={handleSubmit}>
                    <h1>{isSignUp ? "Sign up" : "Login"}</h1>
                    <hr  className="hr" />
                  {isSignUp &&
                        <div>
                            <input type="text" 
                                placeholder="First Name" 
                                className="infoInput" 
                                name="firstName" 
                                value={data.firstName}
                                onChange={handleChange}
                            />
                            <input type="text" 
                                placeholder="Last Name" 
                                className="infoInput" 
                                name="lastName" 
                                value={data.lastName}
                                onChange={handleChange}
                            />
                        </div>
                 }
                    <div>
                        <input type="text" 
                            placeholder="Username" 
                            className="infoInput" 
                            name="username"
                            value={data.username}
                            onChange={handleChange}
                        />
                    </div>
                    <div>
                        <input type="password" 
                            placeholder="Password" 
                            className="infoInput"
                            name="password" 
                            value={data.password}
                            onChange={handleChange}
                        />
                    {isSignUp &&
                            <input type="password" 
                                placeholder="Confirm Password" 
                                className="infoInput" 
                                name="cpassword"
                                value={data.cpassword}
                                onChange={handleChange} 
                            />
                    }
                    </div>

                    {cpasswordError && <span style={{color:"red"}}>*Password and Confirm Password are not the same</span>}
                    <div>
                        <span style={{fontSize:'16px', cursor:'pointer', color:'blue'}} onClick={() => {setIsSignUp((prev) => !prev); resetForm();}}>
                        {isSignUp ? "Already have an account? Login here.." :"Don't have an account? Register here.."}
                        </span>
                        <button type="submit" className="button infoButton">{isSignUp ? "Signup" : "Login"}</button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default Auth;
