import UserModel from "../Models/userModel.js";
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';


export const registerUser = async (req, res) => {
    const { firstName, lastName, email, username, password } = req.body;

    try {
        // Check if the username is already registered
        const existingUser = await UserModel.findOne({ username });
        if (existingUser) {
            return res.status(400).json({ message: 'Username is already registered!' });
        }

        // Hash the password
        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(req.body.password, salt);

        // Create a new user instance
        const newUser = new UserModel({
            firstName,
            lastName,
            email,
            username,
            password: hashedPassword
        });

        // Save the new user to the database
       const user = await newUser.save();
        const token = jwt.sign({
            username: user.username,
            id: user._id
        }, process.env.JWT_KEY,{expiresIn: '1h'})

        // Respond with the newly created user
        res.status(200).json(user, token);
    } catch (error) {
        // Handle any errors
        res.status(500).json({ message: error.message });
    }
};


//Login User
export const loginUser = async(req, res)=>{
    const {username,password} =req.body

    try {
        const user = await UserModel.findOne({username:username})
        if(user){
            const validity = await bcrypt.compare(password, user.password)
            if(!validity){
                res.status(400).json("Wrong Password")
            }
            else{
                const token = jwt.sign({
                    username: user.username,
                    id: user._id
                }, process.env.JWT_KEY,{expiresIn: '1h'})
                res.status(200).json({user, token})
            }
        }
        else{
            res.status(404).json("User does not exist")
        }
    } catch (error) {
        res.status(500).json({message:error.message})
    }
};
