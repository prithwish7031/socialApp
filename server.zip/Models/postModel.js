import mongoose from 'mongoose';

const { Schema } = mongoose;

const postSchema = new Schema({
    userid: { type: String, required: true },
    desc: String,
    likes: { type: Array, default: [] },
    image: String,
},
{
    timestamps: true   
});

export default mongoose.model("Post", postSchema);
